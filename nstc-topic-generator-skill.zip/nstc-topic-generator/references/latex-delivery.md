# M11 LaTeX 交付與品質驗證

## 資料夾與程序
先把 `assets/latex/` 複製到個案工作區，不在技能包內寫研究個資。`main.tex` 是可編輯研究構想模板，不是完成論文；`references.bib` 起初保留空白，僅加入實際核讀且書目核實的來源。`assets/methods.bib` 是本庫方法論參考，不可把它們冒充個案主題近鄰。

1. 預檢 `xelatex`、`latexmk`、中文字型及實際最小編譯，不能只以命令存在宣稱可用。優先 Noto Serif CJK TC；macOS可用 PingFang TC。缺依賴時報明確錯誤；不得改安全設定或任意安裝來源。
2. 填入內容與真實引文，定義公式目標量、符號、單位、假設及反例；資料與分析未執行時明標設計示例。
3. 在副本目錄執行 `bash build.sh draft`，允許待填標記供討論；正式完稿用 `bash build.sh final`，待填、缺字、未定義引用、編譯錯誤不可通過。
4. 複核公式、證據、主張、引用與書目逐項一致。再用 `pdftoppm -r 120 -png build/main.pdf render/page`（先建立render）檢視所有頁面，檢查截斷、重疊、字體、表格、圖例、頁碼、空白頁及可讀性。
5. 機械QA不能替代人工視讀或來源核查。保留編譯log、QA.json、頁面圖、內容校核與已知限制；修正最多兩輪，仍失敗標P HOLD。

手冊使用Pandoc的`--citeproc --bibliography=methods.bib`與`markdown+tex_math_single_backslash`處理引用及公式，再XeLaTeX實編。模板使用natbib/BibTeX，兩條流程分開，不混用引用命令。手冊是使用說明，不能當已完成個案研究。

## 完稿清單
- 未知與假設明列；沒有捏造資料、引文、估計結果或主張保證。
- 每項核心主張可追溯至實讀來源；反面證據沒有隱藏。
- 公式與圖表標記一致，來源與自行推導分清。
- 編譯成功而非只有.tex；無未定義引用、缺字；溢位逐項修正或確認不影響閱讀。
- 所有PDF頁實際視讀；PDF與來源版本一致；交付.tex、.bib、PDF及驗證收據。

技能結構自檢可執行 `python scripts/check_library.py`；它只查資源路徑與方法書目鍵，不是文獻真實性或研究完成驗證。
