# 七項任務的紀錄與接續

在使用者既有研究工作區的 `topic-workflow/` 保存紀錄；不把個案資料寫入技能庫，不覆蓋原稿或舊版本。每步只保存實際完成的輸入、決策、產出、來源與未解。`ready` 代表該步已有真實檔案，不代表整個研究完成。

|任務|建議產出|至少記錄|
|---|---|---|
|1 盤點資源|resource-card.md|專長、現象、資料／時間；已知與待確認|
|2 形成問題|question-candidates.md|對象、情境、問題、重要性及候選邊界|
|3 對照文獻|search-log.csv、nearest-neighbors.md|檢索、來源、讀取層級、已有答案與反向證據|
|4 說清價值|contribution-card.md|既有理解、候選新增理解、理論／實務意義與待驗|
|5 確認可行條件|feasibility.md|資料與權限、能力、時間、缺口與縮題可能|
|6 篩選方向|topic-decision.md|選項、取捨、建議及作者確認或待決|
|7 整理一頁構想|research-brief.md|問題、定位、候選貢獻、條件與下一步|

## 操作
1. `python3 scripts/task_store.py init <個案目錄>/topic-workflow`
2. 依 `assets/task-record.json` 準備實際紀錄，執行 `python3 scripts/task_store.py record <同目錄> <紀錄JSON>`。
3. `python3 scripts/task_store.py check <同目錄>` 讀回任務 1～7；重啟時先讀最新紀錄，不重問或刪除歷史。

新個案使用 1～7；舊版 0～6 個案自動對照為 1～7，保留舊目錄與所有修訂，絕不原地重編號。要混用舊腳本前先備份，避免把新任務記錄交給舊程式誤判。腳本只檢查結構與檔案存在，不能驗證來源真實或作者同意。自審另存 `self-review-findings.csv`，不佔用任務 7。
