# 核讀方法論文獻

核查2026-11-08。這是有界限核心方法搜尋與原文指定段落核讀，不是完整系統性回顧，全文取得不等於逐頁通讀。以下8篇不替代每個候選題的最新領域近鄰與反證搜尋。

## M01 What Constitutes a Theoretical Contribution?

Whetten, David A. (1989). Academy of Management Review, 14(4), 490--495.

DOI: https://doi.org/10.5465/amr.1989.4308371

原文: https://cci.drexel.edu/faculty/sgasson/Readings/Whetten%5B1989%5D-WhatConstitutesATheoreticalContribution.pdf

實讀：原PDF刊頁491圖像核讀。

支持與限制：關係背後理由與邊界，新增變項本身不足以構成理論貢獻；組織理論指引不是官方規則。

## M02 Generating Research Questions Through Problematization

Alvesson, Mats and Sandberg, Jörgen (2011). Academy of Management Review, 36(2), 247--271.

DOI: https://doi.org/10.5465/amr.2009.0188

原文: https://www.4cities.eu/wp-content/uploads/2021/11/ALVESSON-and-SANDBERG-Generating-research-questions-through-problematization.pdf

實讀：刊頁255–256假設類型與方法原則。

支持與限制：辨認並檢查既有假設及替代假設；是反覆思考，不是機械配方或強迫推翻典範。

## M03 Publishing in AMJ—Part 3: Setting the Hook

Grant, Adam M. and Pollock, Timothy G. (2011). Academy of Management Journal, 54(5), 873--879.

DOI: https://doi.org/10.5465/amj.2011.4000

原文: https://www.timothypollock.com/s/amjfte11.pdf

實讀：刊頁873–874 The Product。

支持與限制：問題重要性、現有理解與新知；缺口本身不足以證明重要，AMJ編輯建議非普遍評分。

## M04 Literature Review as a Research Methodology: An Overview and Guidelines

Snyder, Hannah (2019). Journal of Business Research, 104, 333--339.

DOI: https://doi.org/10.1016/j.jbusres.2019.07.039

原文: https://cmapspublic2.ihmc.us/rid=1TWLFN7V2-KPZVYL-SS/Snyder_2019_Literature%20review%20as%20a%20research%20methodology.pdf

實讀：刊頁336–337 §3.1 Table3及搜尋策略。

支持與限制：依問題選回顧設計，透明搜尋篩選萃取；概念整合與效果綜合不應冒用同一標籤。

## M05 Sample Size Justification

Lakens, Daniël (2022). Collabra: Psychology, 8(1), 33267.

DOI: https://doi.org/10.1525/collabra.33267

原文: https://online.ucpress.edu/collabra/article/8/1/33267/120491/Sample-Size-Justification

實讀：Six Approaches、Accuracy、Heuristics、What Is Your Inferential Goal。

支持與限制：以目標、精確度、效果及資源論證樣本；資源限制不自動使資料足夠。

## M06 To Explain or to Predict?

Shmueli, Galit (2010). Statistical Science, 25(3), 289--310.

DOI: https://doi.org/10.1214/10-STS330

原文: https://arxiv.org/pdf/1101.0891

實讀：原文重印§1、§2.2.2、§2.6相關段落，頁碼異於刊版。

支持與限制：描述、解釋與預測分開，樣本外評估；預測好不直接證明因果，也不替代特定識別文獻。

## M07 Building Theories from Case Study Research

Eisenhardt, Kathleen M. (1989). Academy of Management Review, 14(4), 532--550.

DOI: https://doi.org/10.5465/amr.1989.4308385

原文: https://www.mackenzie.br/fileadmin/user_upload/Eisenhardt__1989__Building_Theories_From_Cases_Studies.pdf

實讀：刊頁533 Table1及問題與適用範圍段落。

支持與限制：理論選案、多來源、個案內外比較、相反文獻及收束；非所有質性唯一規範。

## M08 Using Big Data to Emulate a Target Trial When a Randomized Trial Is Not Available

Hernán, Miguel A. and Robins, James M. (2016). American Journal of Epidemiology, 183(8), 758--764.

DOI: https://doi.org/10.1093/aje/kwv254

原文: https://dlab.epfl.ch/teaching/spring2022/cs727/papers/hernan2016using.pdf

實讀：刊頁758–760 Table1資格與分派程序。

支持與限制：先定資格、策略、指派、追蹤、結果、因果對比及分析；資料大不能補足缺少混淆資訊，商管介入需另論證。

## 存取與整合限制
AOM、ScienceDirect、TandF部分入口403，未繞過，使用合法公開作者／大學原文。PMC驗證未解，改用EPFL原文。What If整書超過工具大小限制，不標已讀；ASA p-value聲明未成功取得可讀原文，不納入本批。搜尋涵蓋理論貢獻、問題化、緒論、回顧方法、樣本量、解釋與預測、個案理論生成與target trial；這是定向方法選讀，未保存可重建完整檢索結果集，故不宣稱系統性回顧已完成。

本技能的關注→設計→推理→證據→風險→停止矩陣是本次整合，不宣稱任一篇提出整套流程。方法文獻、講者經驗、官方行政規範及本技能操作延伸必須分開。
