#!/usr/bin/env python3
"""Append-only seven-task store; accepts old 0–6 directories without rewriting them."""
import argparse
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

STAGES = {1: 1, 2: 1, 3: 2, 4: 2, 5: 3, 6: 4, 7: 4}
FIELDS = ('inputs', 'decisions', 'outputs', 'sources', 'unresolved')
STATUSES = {'not_started', 'in_progress', 'waiting_author', 'hold', 'ready'}
SKILL_ROOT = Path(__file__).resolve().parents[1]

def inside_skill(path):
    resolved = path.resolve()
    return resolved == SKILL_ROOT or SKILL_ROOT in resolved.parents

def now():
    return datetime.now(timezone.utc).isoformat()

def save_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def layout(root):
    manifest = root / 'case.json'
    if not manifest.is_file():
        raise ValueError('Missing case manifest; run init first')
    info = json.loads(manifest.read_text(encoding='utf-8'))
    schema = info.get('schema', 1)
    if schema not in (1, 2):
        raise ValueError('Unsupported case schema')
    if schema == 1 and not (root / 'task-0').is_dir():
        raise ValueError('Legacy schema has no task-0; do not guess numbering')
    return info, schema

def task_dir(root, task, schema):
    return root / f'task-{task - 1 if schema == 1 else task}'

def latest(root, task, schema):
    paths = sorted(task_dir(root, task, schema).glob('*.json'))
    return json.loads(paths[-1].read_text(encoding='utf-8')) if paths else None

def init(root):
    root.mkdir(parents=True, exist_ok=True)
    manifest = root / 'case.json'
    if not manifest.exists():
        if (root / 'task-0').exists():
            raise ValueError('Existing task-0 without manifest; preserve and inspect before initializing')
        save_new(manifest, {'schema': 2, 'numbering': '1-7', 'created_at': now(),
                            'case_status': 'active', 'closure_requires': 'explicit user confirmation'})
    _, schema = layout(root)
    for task, stage in STAGES.items():
        if latest(root, task, schema) is None:
            if schema == 1:
                raise ValueError(f'Legacy case missing original task-{task-1}; no files changed')
            save_new(task_dir(root, task, schema) / '000-initial.json',
                     {'task_id': task, 'stage': stage, 'status': 'not_started', 'saved_at': now(),
                      **{key: [] for key in FIELDS}})

def record(root, source):
    _, schema = layout(root)
    r = json.loads(source.read_text(encoding='utf-8'))
    task = r.get('task_id')
    if type(task) is not int or task not in STAGES:
        raise ValueError('task_id must be integer 1..7; self-review is separate')
    if r.get('status') not in STATUSES:
        raise ValueError('Invalid task status')
    for key in FIELDS:
        if not isinstance(r.get(key), list):
            raise ValueError(f'{key} must be an explicitly provided list')
    for decision in r['decisions']:
        if not isinstance(decision, dict) or decision.get('actor') not in ('user', 'assistant'):
            raise ValueError('Decision requires actor user/assistant')
        if decision.get('status') in ('author_confirmed', 'delegated_selection') and not decision.get('confirmation_source'):
            raise ValueError('Confirmed/delegated decision requires confirmation_source')
        if decision.get('status') == 'author_confirmed' and decision['actor'] != 'user':
            raise ValueError('Assistant suggestion is not author confirmation')
    for output in r['outputs']:
        if not isinstance(output, dict) or not output.get('path'):
            raise ValueError('Output needs actual path')
        path = Path(output['path'])
        path = path if path.is_absolute() else root / path
        if inside_skill(path):
            raise ValueError('Skill files cannot be case outputs: ' + str(path))
        if not path.is_file() or not path.stat().st_size:
            raise ValueError('Output missing or empty: ' + str(path))
        output['path'] = str(path.resolve())
    if r['status'] == 'ready' and not r['outputs']:
        raise ValueError('Ready requires actual nonempty output')
    if task == 6 and r['status'] == 'ready' and not any(d.get('status') in ('author_confirmed', 'delegated_selection') for d in r['decisions']):
        raise ValueError('Task 6 ready requires evidenced author decision/delegation')
    r.update({'stage': STAGES[task], 'numbering': '1-7', 'saved_at': now(), 'source_record': str(source.resolve())})
    filename = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '-' + uuid.uuid4().hex[:8] + '.json'
    target = task_dir(root, task, schema) / filename
    save_new(target, r)
    assert json.loads(target.read_text(encoding='utf-8')) == r
    print(json.dumps({'saved': str(target), 'task': task, 'readback_verified': True, 'status': r['status']}, ensure_ascii=False))

def check(root):
    info, schema = layout(root)
    items = []
    for task, stage in STAGES.items():
        r = latest(root, task, schema)
        if r is None:
            raise ValueError(f'Missing task {task}')
        missing = [o['path'] for o in r.get('outputs', []) if not Path(o['path']).is_file()]
        items.append({'task': task, 'stage': stage, 'status': r['status'], 'revision_saved_at': r['saved_at'],
                      'unresolved': r.get('unresolved', []), 'missing_outputs': missing})
    print(json.dumps({'case_status': info['case_status'], 'numbering': '1-7', 'legacy_storage': schema == 1,
                      'tasks': items, 'scope': 'records and file existence, not source truth or consent'}, ensure_ascii=False, indent=2))

def main():
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['init', 'record', 'check'])
    p.add_argument('directory')
    p.add_argument('record_file', nargs='?')
    args = p.parse_args()
    root = Path(args.directory).expanduser().resolve()
    if inside_skill(root):
        raise ValueError('Case records must be outside the installed skill')
    if args.command == 'init':
        init(root)
        check(root)
    elif args.command == 'check':
        check(root)
    else:
        if not args.record_file:
            p.error('record_file required')
        record(root, Path(args.record_file))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, AssertionError, json.JSONDecodeError) as exc:
        raise SystemExit('ERROR: ' + str(exc))
