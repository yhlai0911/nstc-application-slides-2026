#!/usr/bin/env python3
"""Check portable skill resources, not research truth or publication readiness."""
from pathlib import Path
import re,json,sys,csv
root=Path(__file__).resolve().parents[1]
errors=[]
s=(root/'SKILL.md').read_text()
if not s.startswith('---\nname: nstc-topic-generator\ndescription:'): errors.append('Unexpected frontmatter')
for p in root.rglob('*.md'):
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in link or link.startswith('#'):continue
  target=(p.parent/link.split('#')[0]).resolve()
  if not target.exists(): errors.append(f'{p.relative_to(root)}: missing {link}')
for name in ['main.tex','references.bib','build.sh','qa.py']:
 if not (root/'assets/latex'/name).exists():errors.append('Missing LaTeX resource: '+name)
keys=re.findall(r'@article\{([^,]+),',(root/'assets/methods.bib').read_text())
if len(keys)!=8 or len(set(keys))!=8:errors.append('Expected 8 distinct verified methodology entries')
ledger=root/'references/review-point-ledger.csv'
rows=list(csv.DictReader(ledger.open(encoding='utf-8-sig')))
if len(rows)!=92 or len({r['id'] for r in rows})!=92: errors.append('Expected 92 distinct source classification IDs')
if {r['id'] for r in rows if r['page']=='A16'}!={'C7-2','C9-1','C9-4'}: errors.append('Index-only source IDs mismatch')
if any(not all(r.values()) for r in rows): errors.append('Blank source ledger field')
print(json.dumps({'status':'FAIL' if errors else 'PASS','files':sum(p.is_file() for p in root.rglob('*')),'methodology_entries':len(keys),'errors':errors,'scope':'structure and reference paths only'},ensure_ascii=False,indent=2))
sys.exit(bool(errors))
