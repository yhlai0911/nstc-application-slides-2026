#!/usr/bin/env python3
"""Mechanical checks do not replace source verification or visual PDF QA."""
from pathlib import Path
import argparse,json,re,sys
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['draft','final'],default='draft');a=p.parse_args()
root=Path(__file__).resolve().parent
tex=(root/'main.tex').read_text();bib=(root/'references.bib').read_text();log=(root/'build/main.log').read_text(errors='replace')
# Remove comments; preserve escaped percent signs.
active='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in tex.splitlines())
active=re.sub(r'\\verb\*?([^\w\s]).*?\1','',active)
keys=set(re.findall(r'@\w+\s*\{\s*([^,]+),',bib))
cited=set(k.strip() for group in re.findall(r'\\cite\w*\*?(?:\[[^]]*\])*\{([^}]+)\}',active) for k in group.split(','))
errors=[];warnings=[]
for pattern in [r'Undefined control sequence',r'LaTeX Error:',r'Missing character:',r'(?:Citation|Reference) .+ undefined',r'There were undefined references']:
 errors += re.findall(pattern,log)
missing=sorted(cited-keys)
if missing:errors.append('Missing bibliography keys: '+', '.join(missing))
warnings += re.findall(r'Overfull \\[hv]box[^\n]*',log)
placeholders=len(re.findall(r'\\pending\{',active))-1
if placeholders>0:
 (errors if a.mode=='final' else warnings).append(f'{placeholders} draft placeholders remain')
if not (root/'build/main.pdf').is_file():errors.append('PDF missing')
result={'mode':a.mode,'pdf_exists':(root/'build/main.pdf').is_file(),'citation_keys':sorted(cited),'bibliography_keys':sorted(keys),'errors':errors,'warnings':warnings,'visual_review_required':True,'source_verification_required':True}
(root/'build/qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(errors))
