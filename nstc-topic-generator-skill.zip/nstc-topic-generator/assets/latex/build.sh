#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v xelatex >/dev/null || { echo 'Missing XeLaTeX'; exit 1; }
command -v latexmk >/dev/null || { echo 'Missing latexmk'; exit 1; }
mkdir -p build
latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
python3 qa.py --mode "${1:-draft}"
